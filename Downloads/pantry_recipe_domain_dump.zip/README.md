# Pantry & Recipe Domain Database Dump Guide

팬트리(Pantry) 및 레시피(Recipe) 도메인 핵심 5개 테이블의 덤프 파일 안내서입니다. AI팀에 전달하여 모델 학습, 추천/검색 데이터 파이프라인 구축, RAG 임베딩 등에 즉시 활용할 수 있도록 **PostgreSQL 표준 SQL 덤프**와 **개별 테이블 CSV 파일**, 그리고 압축 파일(`pantry_recipe_domain_dump.zip`)을 함께 제공합니다.

---

## 1. 덤프 데이터 개요

- **추출 일시**: 2026-09-21
- **데이터베이스**: `pantrymate_pantryrecipe` (PostgreSQL)
- **문자 인코딩**: UTF-8 (No BOM)

### 포함된 테이블 및 데이터 건수

| 테이블명 | 행 수 (Rows) | 설명 | 주요 외래키(FK) |
|---|---|---|---|
| `ingredients` | 148 | 표준 식재료 사전 (이름, 카테고리, 기본 보관법, 소비기한 등) | - |
| `recipes` | 21,491 | 레시피 기본 정보 (제목, 요리유형, 조리시간, 난이도 등) | - |
| `recipe_ingredients` | 179,603 | 레시피별 필요 식재료 및 용량 매핑 | `recipe_id`, `ingredient_id` |
| `recipe_steps` | 166,436 | 레시피 단계별 조리 가이드 및 설명 | `recipe_id` |
| `recipe_scraps` | 0 | 사용자별 레시피 스크랩 내역 (현재 0건) | `recipe_id` |

> **참고 (PostgreSQL ENUM 타입)**:
> SQL 덤프 파일 최상단에 필요한 ENUM 타입(`storage_type`, `cuisine_type`, `recipe_difficulty`) 생성 DDL이 포함되어 있어 빈 데이터베이스에서도 에러 없이 한 번에 복원됩니다.

---

## 2. 파일 디렉터리 구성

```
db_dump/
├── README.md                          # 본 안내 문서
├── pantry_recipe_domain_dump.sql     # PostgreSQL 전체 복원용 DDL + Data 덤프 (약 35.8MB)
├── pantry_recipe_domain_dump.zip     # 전달용 압축 파일 (약 22.4MB)
└── csv/                              # Python/Pandas 즉시 활용용 CSV 폴더
    ├── ingredients.csv               # 표준 식재료 (148건)
    ├── recipes.csv                   # 레시피 정보 (21,491건)
    ├── recipe_ingredients.csv        # 레시피 식재료 매핑 (179,603건)
    ├── recipe_steps.csv              # 레시피 조리 순서/스텝 (166,436건)
    └── recipe_scraps.csv             # 레시피 스크랩 (0건)
```

---

## 3. 사용 및 복원 방법 (AI팀 가이드)

### 방법 1: Python / Pandas로 바로 열기 (추천: 전처리 & 임베딩 작업)
PostgreSQL을 설치하거나 실행하지 않고 데이터 분석, RAG 임베딩, 모델 파인튜닝을 진행할 때 가장 간편합니다.

```python
import pandas as pd

# CSV 로드
df_ingredients = pd.read_csv('csv/ingredients.csv')
df_recipes = pd.read_csv('csv/recipes.csv')
df_recipe_ingredients = pd.read_csv('csv/recipe_ingredients.csv')
df_recipe_steps = pd.read_csv('csv/recipe_steps.csv')

# 레시피와 스텝 조인 예시
recipe_full = df_recipes.merge(df_recipe_steps, on='recipe_id', how='left')
print(recipe_full[['title', 'step_number', 'description']].head())
```

---

### 방법 2: PostgreSQL DB에 덤프 복원하기 (`psql`)

#### 1) 기존 PostgreSQL 서버가 있는 경우
```bash
# 1. 새 데이터베이스 생성 (예: pantry_recipe_db)
createdb -U postgres -h localhost -p 5432 pantry_recipe_db

# 2. 덤프 파일 실행
psql -U postgres -h localhost -p 5432 -d pantry_recipe_db -f pantry_recipe_domain_dump.sql
```

#### 2) Docker로 1회성 PostgreSQL 띄워서 복원할 경우
```bash
# 1. PostgreSQL 컨테이너 실행
docker run --name ai_pg -e POSTGRES_PASSWORD=postgres -p 5432:5432 -d postgres:16-alpine

# 2. 덤프 파일 컨테이너로 복사 및 실행
docker cp pantry_recipe_domain_dump.sql ai_pg:/dump.sql
docker exec -it ai_pg psql -U postgres -d postgres -f /dump.sql
```

---

### 방법 3: DBeaver / DataGrip / pgAdmin GUI 툴로 열기

1. GUI 툴에서 연결할 PostgreSQL 데이터베이스를 선택합니다.
2. 새 데이터베이스(`pantry_recipe_db`)를 생성합니다.
3. **SQL 편집기(SQL Editor)**를 열고 `pantry_recipe_domain_dump.sql`의 내용을 붙여넣거나 파일 열기를 한 뒤 **전체 실행(Execute Script)**을 누릅니다.
   - 또는 DBeaver의 경우: 데이터베이스 우클릭 → `도구(Tools)` → `데이터베이스 복원(Restore Database)` 선택 후 `.sql` 파일 지정.

---

### 방법 4: DuckDB로 로컬에서 SQL 질의하기 (DB 서버 없이 초고속 SQL 분석)

```bash
# duckdb 실행 후
duckdb
```
```sql
-- CSV 직접 쿼리
SELECT r.title, count(i.recipe_ingredient_id) AS ingredient_count
FROM 'csv/recipes.csv' r
JOIN 'csv/recipe_ingredients.csv' i ON r.recipe_id = i.recipe_id
GROUP BY r.title
ORDER BY ingredient_count DESC
LIMIT 10;
```
